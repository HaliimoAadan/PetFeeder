create function neon_check_for_superuser() returns trigger
    stable
    parallel safe
    language plpgsql
as
$$
BEGIN
    -- Check if current user is superuser
    IF NOT (SELECT rolsuper FROM pg_catalog.pg_roles WHERE rolname = current_user) THEN
        RAISE EXCEPTION 'permission denied for modifying %I.%I', TG_TABLE_SCHEMA, TG_TABLE_NAME
            USING ERRCODE = '42501';
    END	IF;

    RETURN NEW;
END;
$$;

comment on function neon_check_for_superuser() is 'Returns a event trigger that checks if the current user is a superuser';

alter function neon_check_for_superuser() owner to cloud_admin;

