create function get_compute_primary_memory_bytes() returns bigint
    language plpgsql
as
$$
DECLARE
    result BIGINT;
    flag_enabled BOOLEAN;
BEGIN
    -- Check if this is a replica (primary should never emit this metric)
    IF NOT pg_catalog.pg_is_in_recovery() THEN
        RETURN NULL;
    END IF;

    -- Check if the autoscaling state transfer flag is enabled
    -- The flag is exposed as a PostgreSQL GUC by compute_ctl
    -- Note: current_setting returns NULL if the setting doesn't exist (with missing_ok=true)
    -- We treat NULL as "flag not enabled" to be safe
    flag_enabled := pg_catalog.current_setting('neon.autoscaling_state_transfer_enabled', true) = 'on';
    IF flag_enabled IS NULL OR NOT flag_enabled THEN
        RETURN NULL;
    END IF;

    -- Get the value from the table
    SELECT (value)::bigint INTO result
    FROM public.lakebase_attributes
    WHERE name = 'primary_memory' AND value IS NOT NULL;

    -- Return NULL if no row found (COALESCE not used - we want NULL to not emit metric)
    RETURN result;
EXCEPTION WHEN OTHERS THEN
    RETURN NULL;
END;
$$;

alter function get_compute_primary_memory_bytes() owner to cloud_admin;

