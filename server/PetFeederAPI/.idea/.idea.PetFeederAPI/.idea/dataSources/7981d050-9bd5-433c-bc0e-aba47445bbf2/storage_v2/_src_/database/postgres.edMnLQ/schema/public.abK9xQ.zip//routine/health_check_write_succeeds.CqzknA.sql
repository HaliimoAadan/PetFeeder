create function health_check_write_succeeds() returns integer
    language plpgsql
as
$$
BEGIN
INSERT INTO public.health_check VALUES (1, now())
ON CONFLICT (id) DO UPDATE
    SET updated_at = now();

RETURN 1;
EXCEPTION WHEN OTHERS THEN
RAISE EXCEPTION '[NEON_SMGR] health_check failed: [%] %', SQLSTATE, SQLERRM;
RETURN 0;
END;
$$;

alter function health_check_write_succeeds() owner to cloud_admin;

