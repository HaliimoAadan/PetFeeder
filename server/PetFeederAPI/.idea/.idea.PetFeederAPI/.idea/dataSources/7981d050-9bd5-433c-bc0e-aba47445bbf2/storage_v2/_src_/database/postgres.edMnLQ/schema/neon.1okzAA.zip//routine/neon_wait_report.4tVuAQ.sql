create function neon_wait_report(observation_time integer DEFAULT 10, OUT type_name text, OUT event_name text, OUT waits bigint, OUT wait_time numeric, OUT ms_per_wait numeric, OUT waits_per_xact numeric, OUT ms_per_xact numeric) returns SETOF record
    language plpgsql
as
$$
DECLARE
    start_xact_count int8;
    end_xact_count int8;
    total_xacts int8;
    tps numeric;
    start_snapshot neon_wait_event_snapshot[];
BEGIN
    -- Capture initial snapshot as array of composite type.
    -- We use arrays instead of temporary tables to ensure this function
    -- works on read replicas, which cannot create temporary tables.
    SELECT array_agg(ROW(wait_event_id, wait_class_name, wait_event_name, count, time_us)::neon_wait_event_snapshot)
    INTO start_snapshot
    FROM neon_get_wait_event_stats();

    -- Get initial transaction count
    SELECT sum(xact_commit + xact_rollback) INTO start_xact_count
    FROM pg_stat_database;

    -- Wait for the observation period
    PERFORM pg_sleep(observation_time);

    -- Clear the stats snapshot to get fresh values after the sleep.
    -- Without this, pg_stat_database would return cached values from the
    -- same snapshot taken at the start of the function.
    PERFORM pg_stat_clear_snapshot();

    -- Get final transaction count
    SELECT sum(xact_commit + xact_rollback) INTO end_xact_count
    FROM pg_stat_database;

    total_xacts := GREATEST(end_xact_count - start_xact_count, 1);
    tps := total_xacts::numeric / observation_time;

    -- Raise notice about transactions
    RAISE NOTICE 'committed % transactions in % seconds (tps %)',
        total_xacts, observation_time, round(tps, 0);

    -- Compute deltas using efficient set-based operations.
    -- UNNEST converts the snapshot array back to rows for joining.
    RETURN QUERY
    WITH start_data AS (
        SELECT s.wait_event_id, s.wait_class_name, s.wait_event_name, s.count, s.time_us
        FROM unnest(start_snapshot) AS s
    ),
    end_data AS (
        SELECT wait_event_id, wait_class_name, wait_event_name, count, time_us
        FROM neon_get_wait_event_stats()
    ),
    deltas AS (
        SELECT
            COALESCE(e.wait_class_name, s.wait_class_name) AS type_name,
            COALESCE(e.wait_event_name, s.wait_event_name) AS event_name,
            (COALESCE(e.count, 0) - COALESCE(s.count, 0)) AS waits,
            (COALESCE(e.time_us, 0) - COALESCE(s.time_us, 0)) AS delta_time_us
        FROM end_data e
        FULL OUTER JOIN start_data s
            ON e.wait_event_id = s.wait_event_id
    )
    SELECT
        d.type_name,
        d.event_name,
        d.waits,
        round(d.delta_time_us::numeric / 1000, 2) AS wait_time,
        CASE WHEN d.waits > 0
             THEN round((d.delta_time_us::numeric / 1000) / d.waits, 3)
             ELSE 0
        END AS ms_per_wait,
        round(d.waits::numeric / total_xacts, 2) AS waits_per_xact,
        round((d.delta_time_us::numeric / 1000) / total_xacts, 3) AS ms_per_xact
    FROM deltas d
    WHERE d.waits > 0 OR d.delta_time_us > 0
    ORDER BY ms_per_xact DESC;

    RETURN;
END;
$$;

comment on function neon_wait_report(integer, out text, out text, out bigint, out numeric, out numeric, out numeric, out numeric) is 'Shows system-wide wait event activity over a period of time. Takes two snapshots separated by the observation time (default 10 seconds) and returns the delta.';

alter function neon_wait_report(integer, out text, out text, out bigint, out numeric, out numeric, out numeric, out numeric) owner to cloud_admin;

