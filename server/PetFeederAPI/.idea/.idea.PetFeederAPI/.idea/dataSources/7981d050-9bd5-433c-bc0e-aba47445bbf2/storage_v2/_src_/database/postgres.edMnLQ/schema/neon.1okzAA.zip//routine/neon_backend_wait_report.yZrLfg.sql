create function neon_backend_wait_report(pid integer, observation_time integer DEFAULT 10, OUT type_name text, OUT event_name text, OUT waits bigint, OUT wait_time numeric, OUT ms_per_wait numeric) returns SETOF record
    language plpgsql
as
$$
DECLARE
    start_snapshot neon_wait_event_snapshot[];
BEGIN
    -- Capture initial snapshot as array of composite type.
    -- We use arrays instead of temporary tables to ensure this function
    -- works on read replicas, which cannot create temporary tables.
    SELECT array_agg(ROW(wait_event_id, wait_class_name, wait_event_name, count, time_us)::neon_wait_event_snapshot)
    INTO start_snapshot
    FROM neon_get_backend_wait_event_stats(pid);

    -- Wait for the observation period
    PERFORM pg_sleep(observation_time);

    -- Compute deltas using efficient set-based operations.
    -- UNNEST converts the snapshot array back to rows for joining.
    RETURN QUERY
    WITH start_data AS (
        SELECT s.wait_event_id, s.wait_class_name, s.wait_event_name, s.count, s.time_us
        FROM unnest(start_snapshot) AS s
    ),
    end_data AS (
        SELECT wait_event_id, wait_class_name, wait_event_name, count, time_us
        FROM neon_get_backend_wait_event_stats(pid)
    ),
    deltas AS (
        SELECT
            COALESCE(e.wait_class_name, s.wait_class_name) AS type_name,
            COALESCE(e.wait_event_name, s.wait_event_name) AS event_name,
            (COALESCE(e.count, 0) - COALESCE(s.count, 0)) AS waits,
            (COALESCE(e.time_us, 0) - COALESCE(s.time_us, 0)) AS delta_time_us
        FROM end_data e
        FULL OUTER JOIN start_data s
            ON e.wait_event_id = s.wait_event_id
    )
    SELECT
        d.type_name,
        d.event_name,
        d.waits,
        round(d.delta_time_us::numeric / 1000, 2) AS wait_time,
        CASE WHEN d.waits > 0
             THEN round((d.delta_time_us::numeric / 1000) / d.waits, 3)
             ELSE 0
        END AS ms_per_wait
    FROM deltas d
    WHERE d.waits > 0 OR d.delta_time_us > 0
    ORDER BY delta_time_us DESC;

    RETURN;
END;
$$;

comment on function neon_backend_wait_report(integer, integer, out text, out text, out bigint, out numeric, out numeric) is 'Shows wait event activity for a specific backend (identified by PID) over a period of time. Use pg_backend_pid() for current session. Takes two snapshots separated by the observation time (default 10 seconds) and returns the delta.';

alter function neon_backend_wait_report(integer, integer, out text, out text, out bigint, out numeric, out numeric) owner to cloud_admin;

